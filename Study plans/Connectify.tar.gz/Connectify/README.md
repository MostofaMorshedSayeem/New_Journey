# Connectify Social Media v2

This is the v2 version of the Connectify social media site, including Home, About, Explore, Services, Contact, and Login/Signup pages. All pages share a modern, responsive design and navigation. The Contact page features a modern contact block and a row of social media icons as requested.

## Files
- index.html
- about.html
- explore.html
- services.html
- contact.html
- login.html
- style.css
- script.js

## Usage
Open any HTML file in your browser to view the site. All pages are linked via the navigation bar.
